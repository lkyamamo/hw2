In order to run the test cases on your homework, use the following commands in your Docker container:

```
cmake . -DHW_DIR=/path/to/your/hw2/
make
make test
```
